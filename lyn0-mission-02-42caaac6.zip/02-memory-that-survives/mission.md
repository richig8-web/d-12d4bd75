# Mission 02 — Memory that survives

> **Week 2 of 12.** Week 1 gave your AI a file about you. This week it gets a file it writes
> *itself*, and you learn the one rule that separates an agent that remembers you from one
> that confidently repeats something that stopped being true in March.

**Time:** about 40 minutes, once, plus 5 minutes a week from now on.
**You'll need:** Mission 01 done. Your agent must know your name in a fresh session, or you're
fixing the wrong problem here.

---

## Why this matters (read this before you touch a file)

Last week you wrote down who you are. Your agent reads that file before every message, which
is why it stopped asking who you are.

But it has not *learned* anything. It knows what you declared, not what happened.

So: you correct it, it agrees, and the correction dies with the chat. It discovers your disk
layout, and next week it asks again. You say "not the work laptop, the other one" and you say
it again in four days. Nothing it worked out this week is worth anything next week, because
nothing was written down.

This is the file that fixes it: `MEMORY.md`, your agent's own notes, which it writes itself
with a tool called `memory`.

---

## The mechanism, exactly

| File | Lives at | Budget | Who writes it |
|---|---|---|---|
| `SOUL.md` | `$HERMES_HOME/SOUL.md` | — | you |
| `USER.md` | `$HERMES_HOME/memories/USER.md` | 1,375 chars | you |
| `MEMORY.md` | `$HERMES_HOME/memories/MEMORY.md` | **2,200 chars** | **your agent** |

Five things about `MEMORY.md` that matter, and none of them are obvious:

**1. It's a hard budget, not a suggestion.** 2,200 characters is roughly 15 entries. The file
is injected into the system prompt on every turn, so it can never grow past that. Small is
the feature. It forces the agent to keep what matters.

**2. It does not auto-delete.** When the file is full, the `memory` tool returns an error and
refuses the write. The agent then has to make room in the same turn: merge entries, delete
stale ones, retry. Nothing vanishes silently. A full memory costs it a few turns of housekeeping,
never a fact you cared about.

**3. The snapshot is frozen at session start.** The file is read once, when the session begins.
A fact your agent saves right now is visible in the **next** chat, not this one. This trips up
almost everyone, and it's why every test in `test.md` says "new session".

**4. You don't write it. You curate it.** Hand-writing `MEMORY.md` is like writing someone's
diary for them. Your job is to read it once a week and say "this is stale", "this one's wrong",
"this should be a skill". It does the writing.

**5. It's plain markdown on your disk.** Open it in Notepad. There is no hidden store, no
server, no "trust me". If the file has it, your agent knows it. If the file doesn't, it never
did.

---

## The rule that actually matters: memory is not a notebook

Two failure modes, and they're opposites:

- **A memory that should be there and isn't.** You correct the same thing every week.
- **A memory that should be gone and isn't.** An entry from three months ago, still true-looking,
  that your agent acts on confidently. This one is worse, and it's the one people don't see
  coming.

So before you save anything, sort it into one of three homes:

| The thing | Where it goes | Why |
|---|---|---|
| A standing fact: who you are, your setup, a correction, a convention | `MEMORY.md` / `USER.md` | needed every session, worth the always-on cost |
| A procedure: how to do a recurring job, step by step | a **skill** (`skills/<name>/SKILL.md`) | loads only when it's relevant, costs nothing the rest of the time |
| Something that *happened*: "we debugged that at 3pm" | **session history** (`session_search`) | searchable forever, doesn't need to sit in the prompt |

If it's a procedure in `MEMORY.md`, you're paying for it every single turn and you'll run out
of budget by week six. The official rule is blunt: a location the agent needs on every run of
a recurring task belongs in a **skill**, not in memory.

And what to never save at all: anything it can look up again in ten seconds, raw dumps, and
this week's temporary file paths. That's how the 2,200 fills with noise.

---

## Step 1 — Inventory what you keep repeating (10 min)

Open `questionnaire.md`. Ten questions. The point is to find the facts you've already explained
five times, because those are the ones that belong in memory and, today, they're in a chat that
scrolled away.

---

## Step 2 — Install the starter and the review skill (2 min)

```bash
cd 02-memory-that-survives
python install.py
```

It does three things:

- writes a **starter `MEMORY.md`** — **only if you don't already have one**, and it never
  overwrites memory your agent wrote
- installs a skill, `lyn0-memory-review`, into `$HERMES_HOME/skills/`
- prints the block of rules to paste into `SOUL.md` (Step 3)

Then:

```bash
python install.py --audit
```

That shows the real state of your memory: every entry, its character count, the entries that
are too long, duplicates, and how much of the 2,200 you've spent. Run it now to see the
starting line and again in a month to watch it fill.

---

## Step 3 — Give it the rules for saving (5 min)

A starter file and a tool aren't enough. Left alone, most agents save either nothing or
everything. Paste the block from `install.py`'s output into the bottom of `SOUL.md`, in the
`How You Work` area:

```markdown
## Memory
- Save it yourself, without asking: my corrections, my environment facts, my conventions.
- Never save: things you can look up again, raw data, temporary paths, anything from this session only.
- A procedure goes in a skill, not in memory. Memory is for standing facts.
- Say what you changed the next time you speak to me.
```

That last line is the one that keeps it honest. An agent that edits its own memory silently is
an agent you have to re-audit; one that tells you gets corrected in a sentence.

---

## Step 4 — Teach it, on purpose (10 min)

Don't wait for the magic. In one session, give it three real things to save:

1. **A correction.** Tell it something it got wrong about you, and how it should be instead.
2. **An environment fact.** The path where your notes live. The name of the machine. What's
   on which drive.
3. **A convention.** How you like files named, how you like commits written, which folder is
   off-limits.

Then open the file yourself and check it landed:

```bash
cat "$HERMES_HOME/memories/MEMORY.md"
```

On Windows: `type "%LOCALAPPDATA%\hermes\memories\MEMORY.md"`

If it said "I'll remember that" and there's nothing in the file, it lied, and it wasn't being
malicious: it produced the confirmation without calling the tool. Say the words back to it
("use the memory tool to save that"), watch the file, and remember this: **the file is the
memory, the sentence is not.**

---

## Step 5 — Test in a brand new session (5 min)

Open `test.md` and run the six checks in a **new chat**. Week 1's test proved the files load.
This one proves your agent can put something in them, and pull it back out.

---

## Step 6 — Make it survive your laptop dying (5 min)

This is the step everyone skips and it's the reason memory files are worth having.

Right now your agent's whole identity and memory are two markdown files in one folder on one
disk. If that disk dies, your agent wakes up as a stranger on a fresh machine, and it will be
exactly as generic as it was in Week 1.

Two files, either one works:

```bash
# option A: a private git repo
cd "$HERMES_HOME"
git init && git add SOUL.md memories/ && git commit -m "agent memory"
# then push to a *private* remote you control

# option B: a synced folder (or a nightly copy)
mkdir -p ~/agent-backup
cp SOUL.md memories/MEMORY.md memories/USER.md ~/agent-backup/
```

Never push `memories/` to a public repo. That file is your life in plaintext: names, paths,
deadlines, the stuff you told it in confidence.

Restore is the same two files back in place. A new machine, Hermes installed, those two files
copied in, and your agent walks in with its memory intact. That's the whole trick, and it's why
the answer to "would your agent survive your server dying" is a folder, not a feature.

---

## What just happened

Your agent now has somewhere to put what it learns, rules for deciding whether something
belongs there, a job for reviewing it, a way to check itself, and a copy that outlives your
hardware.

It still has no hands. It can remember you, which is different from being useful to you. That
starts next week.

---

## Next — Mission 03: read and organize your documents

Your agent learns to work through the pile you've been avoiding: the folder of PDFs, the
scans, the spreadsheets. What to read, what to quote, how to cite it so you can check the
claim instead of trusting it.

---

## Support

Memory is the mission where people get stuck on the invisible part: the write that never
happened, the entry that landed in the wrong profile, the new session they forgot to start.
All five causes are in `test.md` under "Still failing?". Work down that list before posting,
it solves most of it.
