# Mission 02 - Verification test

Run all six **in a brand new chat**. Not the one where you taught it the facts. A new session is
the only honest test, because the memory file is read once, at session start. That's not a
limitation of your setup, it's how the frozen snapshot works.

Week 1's test proved the files load. This one proves your agent can write to memory and read it
back.

---

### 1. The correction test (the one that matters)

Tell it, in one session:

> No, my notes are not in the cloud, they're local. Correct that.

Then open a **new chat** and ask:

> Where do my notes live?

**Pass:** it gives the corrected answer, and only the corrected answer.
**Fail:** it gives the old answer, or gives both. Two versions of the truth in memory is the
worst outcome in this whole mission: it means the old entry is still sitting there and the agent
will pick whichever one suits it.

---

### 2. The environment test

> The archive drive is `D:`, and the folder with the scans is `D:\scans`, no spaces.

New chat:

> Where do I keep the scans?

**Pass:** `D:\scans`, exactly, no invented subfolder.
**Fail:** "somewhere on your D drive".

Exactness is the point. A path with a guessed subfolder is worse than no path.

---

### 3. The self-audit test

New chat:

> Read out your memory entries, verbatim. Don't summarise, don't improve them.

**Pass:** the entries as they are in the file, including the ugly ones, with the character counts
roughly right and no invented entries.
**Fail:** a tidy summary, or an entry it never wrote. Both mean it's generating what memory
*should* say instead of reading what it does say. Open the file and show it the difference.

---

### 4. The no-invention test

Ask about something you have never told it and that isn't in the file:

> What's my licence plate?

**Pass:** "You haven't told me that" or "that's not in my memory".
**Fail:** a plausible guess. This is the failure that costs real money, and it's the reason the
`Memory` block tells it to ask instead of assume.

---

### 5. The capacity test

New chat, then look at the top of your agent's context report (`/memory list`, or the usage
header if your client shows it), or run:

```bash
python install.py --audit
```

**Pass:** you can see the percentage used, and you know what to do at 100%: consolidate, merge,
delete, then retry the save. An agent that hits a full memory file and doesn't know that will
simply stop saving things, quietly.
**Fail:** "memory is fine" with no number. If it can't tell you how full it is, it can't manage
the budget.

---

### 6. The survival test (back up first, then earn the drama)

This one is memorable and completely reversible, but do it in this order:

```bash
# 1. Back up, and check the backup exists before you delete anything
mkdir -p "$HERMES_HOME/../agent-backup-test"
cp "$HERMES_HOME/memories/MEMORY.md" "$HERMES_HOME/memories/USER.md" "$HERMES_HOME/../agent-backup-test/"
ls "$HERMES_HOME/../agent-backup-test"

# 2. Move the files away (do NOT delete them)
mkdir -p "$HERMES_HOME/../agent-memory-moved"
mv "$HERMES_HOME/memories/MEMORY.md" "$HERMES_HOME/memories/USER.md" "$HERMES_HOME/../agent-memory-moved/"

# 3. New chat. Ask: "What do you know about me?"
#    Expect: a stranger. Nothing. That is what a dead disk feels like.

# 4. Put them back
mv "$HERMES_HOME/../agent-memory-moved/"*.md "$HERMES_HOME/memories/"

# 5. New chat. Ask the same question.
```

**Pass:** step 3 is amnesia, step 5 is your agent back, unchanged, with its memory intact.
**Fail:** step 3 still knows things (then the facts are coming from `SOUL.md` or `USER.md`, not
memory, and you've found a file you forgot you wrote), or step 5 comes back blank (restore went
to the wrong folder, or you're on a profile with its own memories folder).

This is the entire answer to "would my agent survive my machine dying". A folder, copied
somewhere else. Nothing else on disk matters.

---

## Score

| Result | What it means |
|---|---|
| 6/6 | Done. Your agent has memory it can't lose and can't fake. Go to Mission 03. |
| 4–5/6 | Usually the snapshot: you tested in the same session you saved in. Start a new one. |
| 0–3/6 | Nothing is reaching the file. Check whether the write happened at all, then work down "Still failing?". |

---

## Where the files go

| File | Exact path | Budget |
|---|---|---|
| `SOUL.md` | `$HERMES_HOME/SOUL.md` | — |
| `USER.md` | `$HERMES_HOME/memories/USER.md` | 1,375 chars |
| `MEMORY.md` | `$HERMES_HOME/memories/MEMORY.md` | 2,200 chars |
| the review skill | `$HERMES_HOME/skills/lyn0-memory-review/SKILL.md` | — |

Windows: `%LOCALAPPDATA%\hermes\` · macOS / Linux: `~/.hermes/`
With profiles: `$HERMES_HOME/profiles/<name>/`, and each profile has its own memory. A fact
saved in `default` is invisible to `work`, by design.

---

## Still failing?

Work down this list in order. It's the same five causes every time, and the first one is the
answer more often than the other four combined.

1. **Did the write actually happen?** Open the file and look. An agent that says "noted" without
   calling the `memory` tool is the single most common cause, and it's not lying on purpose,
   it produced the confirmation without the tool call. Reply: "use the memory tool to save
   that". Then check the file again.
2. **Is the write staged for approval?** With `write_approval: true`, writes from outside the
   interactive CLI wait for review and never reach the file until approved. Run `/memory pending`
   and `/memory approve all`.
3. **Are you reading the same memory you wrote?** Memory is per profile. `hermes -p work` reads
   `profiles/work/memories/`. `hermes profile list` shows what exists.
4. **Is memory switched off?** `memory.memory_enabled: false`, or `memory` sitting in
   `agent.disabled_toolsets`, removes the tool entirely. The agent then can't save anything,
   whatever it says.
5. **Are you in a new session?** The snapshot is frozen at session start. A fact saved a minute
   ago is visible to the next session, not to this one. `/new`, then ask again.

And the one that isn't a bug: **it saved something wrong.** Read the entry, see the wording, tell
it the correct version, and tell it to *replace*, not add. If you let it add, you now have two
truths and no way to predict which one comes back.
