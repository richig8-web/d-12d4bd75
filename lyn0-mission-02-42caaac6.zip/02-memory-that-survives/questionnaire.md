# Memory inventory — Week 2

Ten minutes. The goal isn't a nice list, it's to catch the facts you've already explained five
times. Those went into chats that scrolled away, and they're about to go into a file your agent
reads before every message.

Write the answers here, then feed them to your agent in Step 4 and check the file after each one.

---

**1. What do you find yourself re-explaining to it?**

The thing you typed again yesterday that you'd typed the week before. Be specific.

___

---

**2. What has it got wrong about you more than once?**

A wrong tool, a wrong day, a wrong name, a wrong assumption about your job. Corrections are the
highest-value memory entries there are: an agent that stops making the same mistake is worth
more than one that learns a new trick.

___

---

**3. Where do your things actually live?**

Machine names, drives, the notes folder, the project folder, the folder it should never touch.
Paths, not descriptions. This is the answer to half of its future questions.

___

---

**4. What's true about your setup that it can't guess?**

Which browser you actually use. That the printer is on a network name, not USB. That your
"work" account and your "personal" account are on different providers. Anything a smart stranger
would assume wrongly.

___

---

**5. Which of those are *conventions* rather than facts?**

Conventions are the rules you repeat without noticing: file naming, date format, commit style,
how you like a summary written, what "done" means for you. List three.

1. ___
2. ___
3. ___

---

**6. What have you asked it to do, step by step, more than once?**

This is a trick question, and the answer is the whole of Week 2. A **recurring procedure** does
not go in `MEMORY.md`, because memory is charged on every turn and a procedure you run monthly
would sit in the prompt forever. It goes in a **skill**. Write the procedure down here, and
you'll turn it into your own skill in Mission 11, or right now if you're impatient (the review
skill you installed in Step 2 is the template).

___

---

**7. What is genuinely temporary?**

The file you're working on this week. The build that failed at 3pm. The thing you're deciding by
Friday. None of it belongs in a 2,200-character file that loads forever. Write down the kind of
thing you'd be tempted to save anyway, so you can recognize it next time.

___

---

**8. What's off-limits, even to memory?**

Health documents, someone else's data, anything with credentials in it. Memory is injected into
the system prompt on every turn, on every machine that profile runs on, and it gets backed up.
If it should never appear in a log, it should never appear in `MEMORY.md` either.

___

---

**9. Who else does your agent need standing facts about?**

Partner, kids, parents, the colleague who sends everything by voice note. One fact each, the one
that changes how it behaves. That's `USER.md` material, and it's the half of memory people fill
in and then never revisit.

___

---

**10. How will you know memory is working?**

Finish this: *"In a month, my agent should never ask me ___ again."*

That's your measurement. Write it down and read it in four weeks.

___

---

## Now what

Run `python install.py`, paste the `Memory` block into `SOUL.md`, then feed your agent the
answers to questions 1 to 5 one at a time and run `python install.py --audit` after each one.
Watching the byte count move is the fastest way to understand why entry 6 doesn't belong in
there. Then run the six checks in `test.md`, in a new session.
