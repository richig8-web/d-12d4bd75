#!/usr/bin/env python3
"""
LYN_0 Academy - Mission 02 installer.

Sets up the memory half of your agent: a starter memories/MEMORY.md (only if you don't already
have one), the lyn0-memory-review skill, and the rules block for SOUL.md.

    python install.py            install the starter memory + the review skill
    python install.py --audit    show every memory entry, its size, and the totals
    python install.py --check    verify only, change nothing
    python install.py --force    replace an existing MEMORY.md (backed up first)

This installer never overwrites memory your agent wrote unless you pass --force, and it always
backs up before it writes. No dependencies, no network calls.

Works on Windows, macOS and Linux.
"""

from __future__ import annotations

import argparse
import os
import shutil
import sys
from datetime import datetime
from pathlib import Path

MEMORY_REL = Path("memories") / "MEMORY.md"
USER_REL = Path("memories") / "USER.md"
SKILL_REL = Path("skills") / "lyn0-memory-review" / "SKILL.md"

MEMORY_LIMIT = 2200
USER_LIMIT = 1375
LONG_ENTRY = 250
DELIM = "\u00a7"  # section sign, how the store separates entries on disk

BANNER = r"""
  LYN_0 Academy - Mission 02
  Memory that survives
"""

SOUL_BLOCK = """## Memory

- Save it yourself, without asking: my corrections, my environment facts, my conventions.
- Never save: things you can look up again, raw data, temporary paths, anything from this session only.
- A procedure goes in a skill, not in memory. Memory is for standing facts.
- When memory is nearly full, merge or delete before you save. Never drop an entry silently.
- If I correct something that's already saved, replace the entry. Don't keep both versions.
- Read memory back verbatim when I ask you to audit it. Never invent an entry.
- When you change memory, say what you changed the next time you speak to me."""


def hermes_home() -> Path:
    """Resolve $HERMES_HOME, falling back to the per-OS default."""
    env = os.environ.get("HERMES_HOME") or os.environ.get("HERMES_AGENT_HOME")
    if env:
        return Path(env).expanduser()

    if sys.platform == "win32":
        base = os.environ.get("LOCALAPPDATA") or (Path.home() / "AppData" / "Local")
        return Path(base) / "hermes"
    return Path.home() / ".hermes"


def strip_comments(text: str) -> str:
    """Drop HTML comment blocks: the store doesn't render them, so they aren't memory."""
    out, depth, i = [], 0, 0
    while i < len(text):
        if depth == 0 and text.startswith("<!--", i):
            depth, i = 1, i + 4
            continue
        if depth and text.startswith("-->", i):
            depth, i = 0, i + 3
            continue
        if depth == 0:
            out.append(text[i])
        i += 1
    return "".join(out)


def parse_entries(path: Path) -> list[str]:
    """Split a memory file into entries on lines containing only the section sign."""
    raw = strip_comments(path.read_text(encoding="utf-8", errors="ignore"))
    entries, buf = [], []
    for line in raw.splitlines():
        if line.strip() == DELIM:
            chunk = "\n".join(buf).strip()
            if chunk:
                entries.append(chunk)
            buf = []
        else:
            buf.append(line)
    chunk = "\n".join(buf).strip()
    if chunk:
        entries.append(chunk)
    return entries


def usage_line(path: Path, limit: int) -> tuple[int, int, int]:
    size = len(path.read_text(encoding="utf-8", errors="ignore")) if path.exists() else 0
    entries = len(parse_entries(path)) if path.exists() else 0
    return size, limit, entries


def report(label: str, path: Path, note: str = "") -> None:
    mark = "OK " if path.exists() else "-- "
    extra = f"  ({note})" if note else ""
    print(f"  [{mark}] {label:<26} {path}{extra}")


def do_audit(home: Path) -> bool:
    print("\nAuditing memory\n")
    healthy = True
    for name, rel, limit in (("MEMORY.md", MEMORY_REL, MEMORY_LIMIT),
                             ("USER.md", USER_REL, USER_LIMIT)):
        path = home / rel
        if not path.exists():
            print(f"  {name}: not found at {path}")
            healthy = False
            continue
        entries = parse_entries(path)
        size = len(path.read_text(encoding="utf-8", errors="ignore"))
        pct = size * 100 // limit
        print(f"  {name}: {len(entries)} entries, {size}/{limit} chars ({pct}%)")
        for e in sorted(entries, key=len, reverse=True):
            flat = " ".join(e.split())
            length = len(e)
            flags = []
            if length > LONG_ENTRY:
                flags.append("too long")
            if "___" in e:
                flags.append("blank left in")
            note = f"   <-- {', '.join(flags)}" if flags else ""
            print(f"      [{length:>4}] {flat[:96]}{'...' if len(flat) > 96 else ''}{note}")
        seen, dupes = set(), []
        for e in entries:
            key = " ".join(e.lower().split())
            if key in seen:
                dupes.append(" ".join(e.split())[:60])
            seen.add(key)
        for d in dupes:
            print(f"      duplicate: {d}")
            healthy = False
        if pct >= 80:
            print("      above 80%: consolidate before adding anything new")
        print()
    print("  What to do with the results:")
    print("    keep    - still true, still needed every session")
    print("    demote  - a procedure: move it into a skill")
    print("    replace - superseded, or two entries saying the same thing")
    print("    delete  - stale, trivial, or re-discoverable in ten seconds")
    print("\n  Ask your agent: \"run a memory review\" - the skill installed by this pack does")
    print("  the walk and proposes the diff, and it will not change anything without your OK.")
    return healthy


def do_check(home: Path) -> bool:
    print("\nChecking installation\n")
    memory, user, skill = home / MEMORY_REL, home / USER_REL, home / SKILL_REL
    report("MEMORY.md", memory, f"{len(parse_entries(memory))} entries" if memory.exists() else "not found")
    report("USER.md", user, "owner profile" if user.exists() else "not found")
    report("review skill", skill, "installed" if skill.exists() else "not found")

    blanks = memory.exists() and "___" in memory.read_text(encoding="utf-8", errors="ignore")
    template_dir = Path(__file__).parent / "files"
    soul_has_rules = False
    soul = home / "SOUL.md"
    if soul.exists():
        soul_has_rules = "## Memory" in soul.read_text(encoding="utf-8", errors="ignore")

    print()
    if not memory.exists():
        print("  No MEMORY.md yet. Run: python install.py")
    if blanks:
        print("  MEMORY.md still has ___ blanks from the starter. Replace them with real entries.")
    if not soul_has_rules:
        print("  SOUL.md has no '## Memory' section yet. Paste the block printed by install.py.")
    if not (template_dir / "MEMORY_TEMPLATE.md").exists():
        print(f"  Template folder missing: {template_dir}")

    ok = memory.exists() and user.exists() and skill.exists() and not blanks
    print("\n" + ("Set up. Run the six checks in test.md, in a new session." if ok
                  else "Not done yet. Fix the lines above, then rerun --check."))
    return ok


def backup(path: Path, home: Path) -> Path | None:
    if not path.exists():
        return None
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    dest = home / "backups" / f"{path.name}.{stamp}.bak"
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, dest)
    return dest


def do_install(home: Path, force: bool) -> None:
    files = Path(__file__).parent / "files"
    src_memory = files / "MEMORY_TEMPLATE.md"
    src_skill = files / "skills" / "lyn0-memory-review" / "SKILL.md"
    if not src_memory.exists() or not src_skill.exists():
        print(f"  Missing pack files under {files}")
        sys.exit(1)

    (home / "memories").mkdir(parents=True, exist_ok=True)
    (home / "skills" / "lyn0-memory-review").mkdir(parents=True, exist_ok=True)

    # MEMORY.md: create it if empty, otherwise leave the agent's own memory alone.
    dst = home / MEMORY_REL
    if dst.exists() and not force:
        entries = len(parse_entries(dst))
        print(f"\n  MEMORY.md already exists ({entries} entries). Left untouched, exactly as it should be.")
        print("  This file belongs to your agent. Wipe it by hand if you want the starter back,")
        print("  or run this installer with --force (it backs up first).")
    else:
        bak = backup(dst, home)
        if bak:
            print(f"\n  Backed up your memory to {bak}")
        shutil.copy2(src_memory, dst)
        print(f"\n  Installed starter {dst}")
        print("  Replace the example entries with your own facts, then run: python install.py --audit")

    # The skill: safe to refresh, it's pack content, not user data.
    shutil.copy2(src_skill, home / SKILL_REL)
    print(f"  Installed skill {home / SKILL_REL}")

    print("\n  Last step, in your agent's own words:")
    print("  paste this into SOUL.md, under 'How You Work' -\n")
    for line in SOUL_BLOCK.splitlines():
        print(f"    {line}")
    print("\n  Then run: python install.py --check")


def main() -> None:
    ap = argparse.ArgumentParser(description="LYN_0 Academy - Mission 02 installer")
    ap.add_argument("--audit", action="store_true", help="show every memory entry and its size")
    ap.add_argument("--check", action="store_true", help="verify only, change nothing")
    ap.add_argument("--force", action="store_true", help="replace an existing MEMORY.md (backs up first)")
    ap.add_argument("--home", type=Path, help="override the Hermes home path")
    args = ap.parse_args()

    home = args.home.expanduser() if args.home else hermes_home()
    print(BANNER)
    print(f"Hermes home: {home}")

    if args.audit:
        sys.exit(0 if do_audit(home) else 1)
    if args.check:
        sys.exit(0 if do_check(home) else 1)
    do_install(home, args.force)
    print()


if __name__ == "__main__":
    main()
