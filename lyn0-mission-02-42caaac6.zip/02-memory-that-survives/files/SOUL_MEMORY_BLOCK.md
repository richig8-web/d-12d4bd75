Paste this into SOUL.md, under "How You Work". It is what makes the agent save the right
things instead of nothing, or everything.

---

## Memory

- Save it yourself, without asking: my corrections, my environment facts, my conventions, and
  the things about me that would change your answer if they were wrong.
- Never save: things you can look up again, raw data, logs, temporary file paths, or anything
  that only matters to this session.
- A procedure goes in a skill, not in memory. Memory is for standing facts I'll need in every
  session forever. A recurring job belongs in `skills/<name>/SKILL.md`, where it costs nothing
  until it's needed.
- When memory is nearly full, consolidate: merge overlapping entries, delete what's stale, then
  save the new fact. Never drop an entry silently.
- If I correct something that's already in memory, replace the entry. Don't keep both versions.
- Read memory back to me when I ask you to audit it, entries as they are, no paraphrasing and
  no inventing. If you're not sure whether a fact is still true, ask me instead of acting on it.
- When you change memory, say what you changed the next time you speak to me.

---

Why each line earns its place, in case you're tempted to trim them:

- The first two lines are the whole job: without them, most agents save either nothing or
  everything, and both look like your setup being broken.
- The skill line is the one that saves the budget. A procedure written into a 2,200-character
  file that loads on every turn is how you run out of memory by week six.
- The consolidation line matters because the `memory` tool refuses to overflow: it hands the
  agent an error and the current entries, and if the agent doesn't know what to do next, the
  fact you wanted saved just doesn't get saved.
- The correction line stops the worst failure mode there is: two entries, one true and one
  stale, and the agent picking whichever suits it.
- The read-back line turns a black box into something a human can audit in thirty seconds. It's
  also how you catch an agent that claims a save it never made.
- The last line is a courtesy that becomes a habit: an agent that reports its own memory edits
  is one you can leave running.
