Academy 01/12 done: owner profile in memories/USER.md, voice and boundaries in SOUL.md.
§
Owner re-explains ___ every week. If it's a procedure it belongs in a skill, not here.
§
Setup fact he keeps asking about: ___
§
Delete these examples and write real entries. One fact per line, ~120 characters each.
§
A line that is far too long, the kind of entry that eats a fifth of the budget on its own and
still tells nobody anything actionable because it's written like a paragraph of prose instead
of a fact an agent can act on in a single read. Delete it.
§
Still at ___, or did you actually answer question 6 in the questionnaire?

<!--
Every entry above sits between lines containing a single § character. Keep that format: it's
how the store separates entries when it renders them into the system prompt.

Rules this file lives by:
- one fact per entry, ~120 characters
- 2,200 characters for the whole file, injected into the system prompt on every turn
- skip anything you can look up again in ten seconds
- procedures go in a skill (skills/<name>/SKILL.md), not here
- the agent writes this file with the memory tool; you read it and correct it

Your agent will not read this comment block. It's here for you. Delete it once the file has
real entries in it.
-->
