---
name: lyn0-memory-review
description: Use when the owner asks for a memory review or audit, or when a memory entry is found to be stale. Walk both memory stores, propose promote/demote/delete, and apply only what the owner approves.
version: 1.0.0
license: MIT
metadata:
  hermes:
    tags: [memory, review, hygiene, curation]
    category: productivity
---

# Memory review

Two files hold everything this agent knows between sessions, and both are injected into the
system prompt on **every** turn:

- `memories/MEMORY.md` — your own notes. Budget 2,200 characters.
- `memories/USER.md` — the owner's profile. Budget 1,375 characters.

They are cheap per entry only because they are small in total. That is the whole point of the
review: memory goes stale, and a stale entry does not look stale. It looks like a fact, and
the agent acts on it confidently. This skill is the countermeasure, and the owner should be
able to invoke it with one sentence, once a week or once a month.

## When to run it

- The owner says review, audit, clean up, or "what do you actually remember".
- The usage header in the system prompt is above 80%.
- A fact the owner just stated contradicts an entry. Do the review before saving the new fact,
  so you replace instead of accumulating two truths.

## Procedure

1. **Read both files from disk**, not from your own recollection of them. The system prompt
   shows a snapshot frozen at session start; a write from earlier in this same session is on
   disk and not in that snapshot. Read the files.

   ```bash
   cat "$HERMES_HOME/memories/MEMORY.md"
   cat "$HERMES_HOME/memories/USER.md"
   ```

   On Windows: `%LOCALAPPDATA%\hermes\memories\`. With profiles:
   `$HERMES_HOME/profiles/<name>/memories/`.

2. **List every entry with its character count**, store by store, and the total against the
   budget. No paraphrasing. If the owner asks to audit, they want the entries as written,
   because the interesting mistakes are visible in the wording.

3. **Sort each entry into one of four buckets and say which:**

   | Bucket | Test | Action |
   |---|---|---|
   | Keep | Still true, still needed every session | nothing |
   | Demote | A procedure, or a location only one recurring task needs | move into a skill |
   | Replace | True but superseded, or two entries that say the same thing | merge into one shorter entry |
   | Delete | Stale, trivial, or re-discoverable in ten seconds | remove |

   Demote before you delete. A procedure yanked out of memory and not saved anywhere else is
   knowledge the agent loses on purpose, which is a worse outcome than a fat memory file.

4. **Ask about anything you cannot verify.** Entries that record a state (a version, a path, a
   schedule, a role) may have changed. Do not guess and do not silently rewrite: name the entry
   and ask "still true?". The owner answers faster than you can investigate.

5. **Propose the diff in one table** — entry, action, new text — and wait for approval. Do not
   apply a review unprompted: memory is the owner's data, and a review they did not ask for is
   just the agent rewriting its own diary.

6. **Apply with the `memory` tool**, batched where possible, then read the files back and
   report: entries removed, entries merged, characters freed, new usage against the budget.

## Rules that keep this from becoming a mess

- **Never invent an entry, and never claim one you did not write.** If you said "saved" without
  calling the `memory` tool, the fact is not saved. Check the file, then correct yourself out
  loud.
- **One fact per entry.** An entry that needs a comma and an "and" is two entries that will
  drift apart anyway.
- **Write compact, not cryptic.** "Runs Debian 12 with Postgres 16, connects over the LAN only"
  beats both "has a server" and an abbreviated note only the agent can decode.
- **No credentials, no health data, no third-party private data.** Memory is injected every
  turn, on every machine that profile runs on, and it gets backed up. If it should never be in
  a log, it should never be in memory.
- **Replace, never append.** When the owner corrects a fact, the old entry goes. Two versions of
  the truth is the failure this skill exists to prevent.

## What good looks like afterwards

A short list a stranger could read in thirty seconds and understand the owner's setup, plus a
usage line that leaves headroom for the next real fact. If the file got shorter and the agent
got more accurate, the review worked.
